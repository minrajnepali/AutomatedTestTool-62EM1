# AutomatedTestTool-62EM1

Instructions to set up the Software. I recommend using Windows 10 or higher for proper functioning of the Software.

Copy the folder on the Desktop (recommended).
Inside the AutomatedTestTool-62EM1 folder, go to the folder called 'bin'. 
From 'bin' go to 'Debug' folder.
From Debug Folder, right click on 'AutomatedTestTool62EM1.exe' and create a short cut. 
The 'AutomatedTestTool62EM1 - Shortcut' should be created on the Debug Folder. Copy that shortcut and place it on Desktop (recommended).
Click "AutomatedTestTool62EM1 - Shortcut' to run the application. Make sure all the connections are completed and devices are powered up before clicking 'AutomatedTestTool62EM1 - Shortcut' to run the application (see section 3 & 4 on the User Guide (Manual)).
